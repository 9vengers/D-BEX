Documentation
=============

Internal Links:

 * [Developer Documentation](dev-docs.md)
 * [Supported SQL Queries](syntax-support.md)
 * [Known Limitations & Missing Features](known-limitations.md)
 * [Basic Usage](basic-usage.md)


External Resources:

 * [Original Dev-Paper (2015)](http://torpedro.com/paper/HyriseSQL-03-2015.pdf)
